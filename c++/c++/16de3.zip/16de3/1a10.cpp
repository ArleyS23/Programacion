#include <iostream>
#include <string>

using namespace std;

int main() {

int N;
cout<<"Programa que solo recibe numeros de 1 a 10\n";
do{
cout<<"Digite un numero: \n";
cin>>N;
}while (N <= 10);
cout<<"Solo se permiten numeros del 1 a 10";

}