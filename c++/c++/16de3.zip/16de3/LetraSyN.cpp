#include <iostream>
#include <string>

using namespace std;

int main() {

string L;
do{
cout<<"Digite S para continuar y N para finalizar\n";
cin>>L;
}while (L !="N");

}