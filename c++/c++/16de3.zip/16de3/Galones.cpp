#include <iostream>
#include <string>

using namespace std;

int main() {

for (float i = 10; i < 21; i++){
    cout<<i<<" galones equivalen a "<<(i*3.785)<<" litros\n";
}

}