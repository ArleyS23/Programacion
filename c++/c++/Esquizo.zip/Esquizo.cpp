#include <iostream>
using namespace std;

int main (){

int pico, destornillador, martillo;
int lonchera = 0;
int loco = 0;
int Gorro;
int Decision;
int Pastillas;
int Bien = 0;
int mal = 0;
int gasolina = 0;
int tapon, conver;

cout<<"_______________Esquizo_______________"<<endl;
cout<<"Sipnosis"<<endl;
cout<<"Somo un niño llamado Will que ve como sus padres tienen una pelea haciendo que su padre lo abandonará,\ntiene que asistir a sus consultas con el doctor ya que él tiene amigos imaginarios pero claramente nadie le\ncree. En la escuela un grupo de chicos le hacen acoso escolar, sus supuestos amigos imaginarios se enteran\ny así uno intenta vengarse, Nuestros amigos imaginarios nos darán consejos según avanza los días con la ,\nintención de ayudarlos con nuestros problemas tomando varias decisiones que nos llevarán a diferentes finales."<<endl;
cout<<"_______________Comencemos_______________"<<endl;

//Comienzo de la historia 
cout<<"Hay seres con galaxias en sus mentes\nhay otros que no tienen galaxias,\nsino...\nuniversos enteros.\ncosas alejadas de la comprension humana...\ny no necesariamente pueden ser buenas."<<endl;
cout<<"*Te levantas de la cama y escuchas a tu papas discutiendo*"<<endl;
cout<<"Papa: Pero ¿que quieres que yo haga mujer?"<<endl;
cout<<"Papa: ¿QUE QUIERES QUE YO HAGA"<<endl;
cout<<"Papa: ¿Que hacemos con le nino?"<<endl;
cout<<"Papa: Te recuerdo que tu fuiste la que querias tener ninos."<<endl;
cout<<"Mama: Quisimos... los dos quisimos tener ninos. te lo recuerdo yo a ti..."<<endl;
cout<<"Mama: De esta manera no se solucionan los problemas ¡por Dios!"<<endl;
cout<<"Papa: ¿Pero dime que le voy a decir?"<<endl;
cout<<"Papa: ¡DIME ALGO AYUDAME!"<<endl;
cout<<"Mama: ¡DEJAME PENSAR!"<<endl;
cout<<"Papa: Sabes que... yo me largo."<<endl;
cout<<"Papa: ¡ME LARGO!"<<endl;
cout<<"*Papa se va de la casa y muere en un accidente*"<<endl;
cout<<"Se fue..."<<endl;
cout<<"Se fue para siempre"<<endl;
cout<<"*Un ano despues*"<<endl;
cout<<"Estas bajo la lluvia y entras en un hospital donde encuentras a tu mama esperandote"<<endl;
cout<<"Mama: ¿Donde estabas Will?, Ah no importa..."<<endl;
cout<<"Mama: Vamos, el doctor debe estar esperando"<<endl;
cout<<"*Caminas por un pasillo hasta llegar a la sala del Doctor*"<<endl;
cout<<"Mama: Ya sabes carino... Comportante y mucho respeto al doctor"<<endl;
cout<<"Esta bien mama."<<endl;
cout<<"Doctor: Buenas Noches, Will ¿Como te has sentido estos dias"<<endl;
cout<<"Mama: Pues Doctor, el sigue hablando con sus amigos imaginarios, sigue teniendo sus alucinaciones..."<<endl;
cout<<"MAMA... te he dicho miles de veces que no son amigos imaginarios. ¡son reales!"<<endl;
cout<<"Doctor: Will, nada de esas voces y alucinaciones son reales, todo eso lo crea tu cabeza..."<<endl;
cout<<"Doctor: por eso necesito que tomes los medicamentos que te indiqué."<<endl;
cout<<"AHHHH... TODO ESO ES MENTIRA... SON LOS UNICOS AMIGOS QUE TENGO Y ME LOS QUIEREN QUITAR"<<endl;
cout<<"Mama: WILL COMPORTATE"<<endl;
cout<<"Me..."<<endl;
cout<<"Me largo de aqui..."<<endl;
cout<<"Ahhh... cuantas veces tendre que decirlo, son mis amigos y yo los entiendo"<<endl;
cout<<"......................."<<endl;
cout<<"Hey... ¡Hey! ¿que pasa?"<<endl;
cout<<"......................."<<endl;
cout<<"Tired: Hola Will... ¿Como has estado?"<<endl;
cout<<"Bien, algo cansado, ¿Que haces aqui?"<<endl;
cout<<"Tired: Eso no importa, Cuantas veces tendre que decirte que no vengas a ver el estupido doctor"<<endl;
cout<<"Tired: Lo que quiere de ti es el dinero de tu madre... nada mas"<<endl;
cout<<"Si lo se... yo no queria venir, pero mi mama me obligo, no pude hacer nada."<<endl;
cout<<"Tired: Bueno Will, no importa... ven acompaname, tengo algo que mostrarte."<<endl;
cout<<"Tired: Toma eso lo vas a necesitar"<<endl;
cout<<"*Te da un gorro de fiesta*, ¿te lo pones?"<<endl;
cout<<"1-Si.\n2-No"<<endl;
cin>>Gorro;
cout<<"*Sales del hospital y vas con tus amigos a una fiesta en tu habitacion*"<<endl;
cout<<"¡WOOOOW!"<<endl;
cout<<"Que buena fiesta, y justamente en mi habitacion, hasta parece subrreal..."<<endl;
cout<<"Tired: Claro que si will... es hora de disfrutar de la gran fiesta..."<<endl;
cout<<"Tired: Con tu verdadera familia... que somos nosotros"<<endl;
cout<<"Tired: Alejado de todos esos doctores que te ven todos los dias..."<<endl;
cout<<"Tired: No te quedes ahi parado... VEN, VEN"<<endl;
cout<<"Reflection: Will..."<<endl;
cout<<"Help: ¿Como estas mi pequeno?"<<endl;
cout<<"Hola Refletion y Help."<<endl;
cout<<"Reflection: Cuentanos William que has hecho, aunque ya lo sabemos je je je..."<<endl;
cout<<"Ehhhh... pues no muchas cosas, por lo general paso mi mayor tiempo en el colegio, ahora."<<endl;
cout<<"Help: Y Will ¿te esta yendo bien con tus amigos en el colegio?"<<endl;
cout<<"Si, si, tengo muchos amigos... si amigos... claro."<<endl;
cout<<"en realidad no tengo amigos... Nadie se divierte conmigo, me dicen -Gusano-"<<endl;
cout<<"Todos los dias almuerzo solo en el comedor, quisiera que eso cambiara"<<endl;
cout<<"Tired: JA JA JA... ¿A veces no deseas que todos estuvieran muertos?"<<endl;
cout<<"¿QUE? creo que estas exagerando Tired"<<endl;
cout<<"Reflection: No hay que llegar a esos extremos"<<endl;
cout<<"Help: A mi pequeno nadie lo puede tocar"<<endl;
cout<<"Tired: Tranquilo Will, tarde o temprano entenderan que deben dejar de molestarte."<<endl;
cout<<"Eso espero..."<<endl;
cout<<"........................."<<endl;
cout<<"Mama: Willll..."<<endl;
cout<<"???????.....¿MAMA?"<<endl;
cout<<"Mama: ¡Will despierta!, WILLLLLLLLL"<<endl;
cout<<"*Despiertas en tu habitacion y ya es de madrugarda*"<<endl;
cout<<"Mama: Vamos will tienes que ir a la escuela, ya son las 7:00..."<<endl;
if (Gorro==1){
    cout<<"Mama: Espera un momento... ¿por que tienes ese gorro?"<<endl;
    cout<<"De la fiesta de ayer, ¿no escuchaste el ruido?"<<endl;
}
cout<<"Mama: psss, por Dios Will, si ayer te quedaste dormido en el pasillo del hospital"<<endl;
cout<<"............"<<endl;
cout<<"Mentiras...."<<endl;
cout<<"Bueno olvidalo, te tienes que ir ya, en la cocina te deje tu lonchera con tu desayuno para que lo lleves"<<endl;
cout<<"Mama: Tambien necesito que tomes la pastilla de la manana."<<endl;
cout<<"Mama: Recuerda que es la que dice Antipsicotico. bueno...."<<endl;
cout<<"Mama: te quiero mucho carino, que te vaya muy bien en tu dia..."<<endl;
cout<<"Mama: Nos vemos en la noche para cenar..."<<endl;
cout<<"Esta bien, nos vemos en la noche"<<endl;
cout<<"...............¿?"<<endl;
cout<<"¿Quedarme dormido?"<<endl;
cout<<"Pero si recuerdo toda la fiesta perfectamente"<<endl;
cout<<"Estoy seguro de que no fue un sueño"<<endl;
cout<<"*encuentras en la mesa varias pastillas*\n¿Cual era la que debias tomar?"<<endl;
cout<<"1-Aspirina.\n2-Antialergico.\n3-Antipsicotico.\n4-Vitamina C"<<endl;
cin>>Pastillas;
if (Pastillas == 3){
    Bien++;
}
cout<<"Bien ya la tengo, voy a ir a la nevera por un poco de agua"<<endl;
cout<<"*Entras a la cocina*"<<endl;
do{
cout<<"1-Tomar lonchera.\n2-Tomar pasta.\n3-irte"<<endl;
cin>>Decision;
if (Decision == 1 ){
    cout<<"*Tomaste la lonchera*"<<endl;
    lonchera++;
}
else if(Decision == 2){
    if (Pastillas == 3){
        cout<<"*Tomaste la pastilla correcta*"<<endl;
    }else{
        cout<<"Creo que esa pastilla no era"<<endl;
    }
}
else if (Decision == 3){
    cout<<"Aun no me puedo ir, me falta algo"<<endl;
}
} while (Decision != 2);
if (Pastillas == 3){
    Bien++;
}else{
    loco++;
    cout<<"*Comienzas a oir voces y ver como se distorcionan las cosas*"<<endl;
    cout<<"Pero ¿que ha sido eso?"<<endl;
    cout<<"................"<<endl;
}
cout<<"dedo irme, se me hace tarde"<<endl;
if (Gorro == 1){
    cout<<"Sera mejor que me quite este gorro, si no quiero hacer el ridiculo en clases.";
}else{
    cout<<"";
}
cout<<"*Estas en el colegio*"<<endl;
cout<<"Es mejor que me apresure, voy con 30 minutos de retraso"<<endl;
cout<<"*Nota de la directora*"<<endl;
cout<<"Se les inroma que el 15 de mayo no habra clases... esto es debido al festival de las calabazas del pueblo."<<endl;
cout<<"Atentamente su directora... Que pasen un buen dia"<<endl;
cout<<"quieres entrar al baño antes de clase?"<<endl;
cout<<"1-si\n2-no"<<endl;
cin>>Decision;
if (Decision == 1){
    cout<<"Espera que es ese ruido"<<endl;
    cout<<"................"<<endl;
    cout<<"seguro es mi imaginacion"<<endl;
    cout<<"!!!!!!!!!!!!!!!!!!"<<endl;
    cout<<"¿que ha sido eso?"<<endl;
    cout<<".................."<<endl;
    cout<<"no ha sido nada, debo estar loco"<<endl;
    cout<<"........................."<<endl;
}else if (Decision == 2){
    cout<<""<<endl;  
}
cout<<"*Entras a clase*"<<endl;
cout<<"chuck: ¡Hey miren llego el gusano! "<<endl;
cout<<"itan: JAJAJAJAJAJAJ"<<endl;
cout<<"stuard: jajajajajaj"<<endl;
cout<<"carbon: jejejejej....."<<endl;
cout<<"Maestra: Dejen de burlarse de su compañero, te tendre que bajar puntos por lo que dijiste chuck"<<endl;
cout<<"chuck: Haga lo que quiera maestra, chupela jajajaj"<<endl;
cout<<"._."<<endl;
cout<<"Maestra: Buenos dias will.."<<endl;
cout<<"Maestra: bueno, quiero decir burnas tardes, ya que estas no son horas de llegar"<<endl;
cout<<"Lo siento profesora... tuve algunos incovenientes en mi casa"<<endl;
cout<<"Maestra: Toma asiento Will"<<endl;
cout<<"Bueno sigamos con la clase....."<<endl;
cout<<"En 11 de septiembre fue una fecha...."<<endl;
cout<<"la cual cun grupo de...."<<endl;
cout<<"y eso fue lo que...."<<endl;
cout<<"*Despues de un rato*"<<endl;
cout<<"Maestra: Bueno... pueden salir a desayunar, recuerden que tienen 30 minutos"<<endl;
cout<<"Que hambre tengo, voy al comedor"<<endl;
cout<<"chuck: !Hey will.. espera"<<endl;
cout<<"¿?¿?¿?¿?¿?¿?"<<endl;
cout<<"chuck: La verdad lo siento por lo que te dije en el salon"<<endl;
cout<<"......................"<<endl;
cout<<"¿Me lo estas diceindo en serio?"<<endl;
cout<<"chuck: si... lo estoy diciendo en serio"<<endl;
cout<<"Esta bien chuck, no te preocupes"<<endl;
cout<<"chuck: es mas, por que no nos acompañas al final del dia al parque abandonado, solemos juagr y pasar le rato ahi"<<endl;
cout<<"Ehhhhh.. no suelen invitarme a ningun lado, pero bueno me voy a pasar por alla"<<endl;
cout<<"chuck: vale muy bien, entonces nos vemos"<<endl;
cout<<"Nos vemos.........."<<endl;
cout<<"Que raro estuvo eso"<<endl;
cout<<"¿Ya dejaron de molestarme?"<<endl;
cout<<"bueno, vamos a comer"<<endl;
cout<<"......................."<<endl;
if (lonchera == 1){
    cout<<"Que bueno que traje mi lochera :)"<<endl;
}else{
    cout<<"*No tragiste la lonchera*"<<endl;
    cout<<"Que hambre tengo!!"<<endl;
    mal++;
}
cout<<"....................."<<endl;
cout<<"Y asi se resume un dia en el colegio...."<<endl;
cout<<"aburrido..."<<endl;
cout<<"solo..."<<endl;
cout<<"y..."<<endl;
cout<<"triste..."<<endl;
cout<<"pero hoy me invitaron a ir al parque abandonado"<<endl;
cout<<"tengo un mal presentimiento"<<endl;
cout<<".........................."<<endl;
cout<<"Hola chicos."<<endl;
cout<<"chuck: Ahh hola gusano... digo, digo, will, perdoname"<<endl;
cout<<"...."<<endl;
cout<<"Esta bien chuck"<<endl;
cout<<"itan: Estamos viendo como hacer funcionar los carros chocones"<<endl;
cout<<"carbon: yo creo que no van a funcionar, estan totalmente dañados"<<endl;
cout<<"itan: no digas eso carbon, tienen que tener reparacion"<<endl;
cout<<"stuard: solo faltan arreglar el generador de electricidad que esta dañado y tambien falta buscarla ya que no se donde esta jajaja"<<endl;
cout<<"carbon: ayyy... si sabelo todo ¿como crees que arreglaremos un generador de electricidad?"<<endl;
cout<<"stuard: pues yo si puedo arreglar, ya que soy mas inteligente que ustedes con diferencia"<<endl;
cout<<"...."<<endl;
cout<<"itan: lo que tiene de inteligente lo tienes de arrogante"<<endl;
cout<<"stuard: ¿como has dicho?...¡ahora si te las veras conmigo itan johson!"<<endl;
cout<<"*pelean epicamente*"<<endl;
cout<<"chuck: ¡YA PAREN!... parecen unos idiotas"<<endl;
cout<<"stuard: comenzo el"<<endl;
cout<<"chuck: por que no le mostramos la sorpresa a will"<<endl;
cout<<"carbon: ¿sorpresa?"<<endl;
cout<<"stuard: ¿¿¿¿¿"<<endl;
cout<<"itan: ??????"<<endl;
cout<<"¿que sorpresa?"<<endl;
cout<<"chuck: ¿Que acaso no recuerdan la sorpresa?"<<endl;
cout<<"carbon: ahhhhhhhh esa sorpresa"<<endl;
cout<<"chuck: ven will acompañanos"<<endl;
cout<<"chuck: tu sorpresa esta detras de esa puerta"<<endl;
cout<<"itan: vamos will te gustara...."<<endl;
cout<<"stuard: Entra."<<endl;
cout<<"*Entrar por la puerta y te dejan encerrado*"<<endl;
cout<<"chuck: JAJAJAJAJAJAJAJ"<<endl;
cout<<"chuck: ¿creias que te dejariamos de molestar gusano?"<<endl;
cout<<"Confie en ustedes, por favor no me dejen aqui solo"<<endl;
cout<<"Chuck: callate puta jajajajaja"<<endl;
cout<<"¡Hey! por favor no me dejen..."<<endl;
cout<<"¡por favor!"<<endl;
cout<<"chuck: Dile a tus amigos imaginarios que te rescaten jajajajaja"<<endl;
cout<<"itan: JAJAJAJAJAJAJ"<<endl;
cout<<"stuard: jajajajajaj"<<endl;
cout<<"carbon: jejejejej....."<<endl;
cout<<"¡HEY ESPEREN! ¡NO SE VAYAN!"<<endl;
cout<<"¡POR FAVOR QUE ALGUIEN ME AYUDE!"<<endl;
cout<<"ayuda..."<<endl;
cout<<"Ahora que hago..., tengo mucho miedo."<<endl;
cout<<"Tired: Hey will"<<endl;
cout<<"¿Tired?"<<endl;
cout<<"Tired: se fuerte mi pequeño, pronto sabran con quienes se han metido"<<endl;
cout<<"Tired: muy pronto lo sabran..."<<endl;
cout<<"¡Hey ayudame a salir por favor!"<<endl;
cout<<"......"<<endl;
cout<<"¿TIRED?"<<endl;
cout<<"AYUDAAAAAA..."<<endl;
cout<<"........."<<endl;
cout<<"Voy a buscar la manera de salir de aqui"<<endl;
do{
cout<<"Hay 3 puertas"<<endl;
cout<<"por cual entro?"<<endl;
cout<<"1-Puerta 1"<<endl;
cout<<"2-Puerta 2"<<endl;
cout<<"3-Puerta 3"<<endl;
cin>>Decision;
if (Decision == 1){
    cout<<"hay una ventana ya es de noche"<<endl;
}else if (Decision == 2){
    cout<<"*Hay un generador de electricidad*"<<endl;
    cout<<"no estoy seguro si funciona, creo que con gasolina deria encender"<<endl;
    if (gasolina == 1){
        cout<<"voy a vertir la gasolina"<<endl;
        cout<<"supongo que ya deberia funcionar el generador"<<endl;
        cout<<"veamos..."<<endl;
        cout<<"*Regresa la electricidad*"<<endl;
        cout<<"Wow, si funciono"<<endl;
    }
    cout<<"mas adelante hay un puerta cerrada"<<endl;
    cout<<"Presionar panel con botones?"<<endl;
    cout<<"1-si"<<endl;
    cout<<"2-no"<<endl;
    cin>>Decision;
    if ((Decision == 1)&&(gasolina == 1)){
        cout<<"*Se abre la puerta*"<<endl;
    }else if ((Decision == 1)){
        cout<<"no funciona necesita electricidad"<<endl; 
        Decision = 22;
    }else{
    }
}else if (Decision == 3){
    do{
    cout<<"Hay 3 puertas"<<endl;
    cout<<"por cual entro?"<<endl;
    cout<<"1-Puerta 1"<<endl;
    cout<<"2-Puerta 2"<<endl;
    cout<<"3-Puerta 3"<<endl;
    cout<<"4-Devolverse"<<endl;
    cin>>Decision;
    if (Decision == 1){
        cout<<"Esta cerrada"<<endl;
    }else if (Decision == 2){
        do{
        cout<<"No hay nada en este cuarto >:("<<endl;
        cout<<"salir?"<<endl;
        cout<<"1-si"<<endl;
        cout<<"2-no"<<endl;
        cin>>Decision;
        if (Decision == 2){
            cout<<"y ahora que?"<<endl;
        }else{
        }
        } while (Decision != 1);
    }else if (Decision == 3){
        cout<<"Hay una puerta"<<endl;
        cout<<"entrar?"<<endl;
        cout<<"1-si"<<endl;
        cout<<"2-Devolverse"<<endl;
        cin>>Decision;
        if (Decision == 1){
            cout<<"Un bidon de gasolina"<<endl;
            cout<<"Sera mejor que lo lleve me debe servir para algo"<<endl;
            gasolina = 1;
        }else{
            cout<<""<<endl;
        }
    }else if (Decision == 4){
        cout<<""<<endl;
    }
    } while (Decision !=4);
}
} while (Decision != 22);
cout<<"ohh si una salida por fin"<<endl;
cout<<"desde aqui puedo ver todo el parque..."<<endl;
cout<<"pero no puedo saltar desde este segundo piso, me partiria las piernas"<<endl;
cout<<"necesito una cuerda para poder bajar"<<endl;
cout<<"hay unas cuerdas colgando del techo"<<endl;
cout<<"me podrian servir..."<<endl;
do{
cout<<"tomar cuerdas?"<<endl;
cout<<"1-si"<<endl;
cout<<"2-no"<<endl;
cin>>Decision;
if (Decision == 2){
    cout<<"Necesito las cuerdas"<<endl; 
}else{
    cout<<""<<endl;
}
} while (Decision != 1);
cout<<"vale, ya tengo cuerda"<<endl;
cout<<"pero necesito un lugar donde atarla"<<endl;
do{
cout<<"¿cual puede ser un buen lugar?"<<endl;
cout<<"1-lampara"<<endl;
cout<<"2-columna"<<endl;
cout<<"3-ladrillo"<<endl;
cin>>Decision;
if (Decision == 1){
    cout<<"Es muy fragil, no aguantaria mi peso"<<endl;
}else if (Decision == 2){
    cout<<"Puedo atar la cuerda a esta columna"<<endl;
    cout<<"creo que servira.."<<endl;
    cout<<".........."<<endl;
    cout<<"Vale ya esta puesta es hora de bajar"<<endl;
    cout<<"*baja epicamente*"<<endl;
}else if (Decision == 3){
    cout<<"estoy bromeando, me mataria"<<endl;
}
} while (Decision != 2);
cout<<"*Vas a casa*"<<endl;
cout<<"Mama: Hay por Dios will me tenias preocupada"<<endl;
cout<<"Mama: mirate estas todo mojado, te puedes resfriar"<<endl;
cout<<"Mama: ¿en donde estabas?"<<endl;
cout<<"Mis compañeros de clase me invitador a jugar al parque abandonado"<<endl;
cout<<"Mama: Will sabes que no me gusta mucho ese lugar, es peligroso"<<endl;
cout<<"Mama: pero de todas maneras ¿como las pasaste con tus amigos? ¿bien?"<<endl;
cout<<"Ehhhh...."<<endl;
cout<<"Muy bien mama, muy bien..."<<endl;
cout<<".................."<<endl;
cout<<"................."<<endl;
cout<<"¿En donde estoy?"<<endl;
cout<<"....Espera un momento, aqui es donde soliamos jugar beisbol mi padre y yo"<<endl;
cout<<"Aun sigue escrito la puntuacion de nuestro juego"<<endl;
cout<<"Papa: Hey will..."<<endl;
cout<<"...."<<endl;
cout<<"¿Papa? ¿eres tu?"<<endl;
cout<<"¡Wow! ¡si eres tu!"<<endl;
cout<<"Papa: No sabes cuanto te extraño will"<<endl;
cout<<"Quisiera jugar al beisbol como soliamos hacerlo"<<endl;
cout<<"Papa: Como me gustaria hijo..."<<endl;
cout<<"Papa: pero sabes estoy en otro plano terrenal..."<<endl;
cout<<"Papa: y tengo algo importante que decirte"<<endl;
cout<<"Vale ¿que tienes que decirme?"<<endl;
cout<<"Papa: No dejes que esos monstruos dominen te cabeza"<<endl;
cout<<"Papa: tu eres mas fuerte...."<<endl;
cout<<"Papa: controla a tu cosmos cerebral"<<endl;
cout<<"¿Pero de que me hablas? ¿Que monstruos?"<<endl;
cout<<"¿Mis amigos imagninarios?"<<endl;
cout<<".................."<<endl;
cout<<"¿Papa?"<<endl;
cout<<"¿Estas ahi?"<<endl;
cout<<".................."<<endl;
cout<<"Ahhh... Mi cabeza, que sueño tan eztraño tuve"<<endl;
cout<<"...."<<endl;
cout<<"¿y mi mama?"<<endl;
cout<<"de seguro salio mas temprano al trabajo..."<<endl;
cout<<"y y o debo irme ya, se me hacer tarde"<<endl;
do{
cout<<"Vale el medicamento"<<endl;
cout<<"1-Antipsicotico"<<endl;
cin>>Pastillas;
if (Decision == 1){
    cout<<"Vale ya la tengo.."<<endl;
}else{}
} while (Decision != 1);
cout<<"ire al refrigerador a por un poco de agua."<<endl;
cout<<"Una nota de mi madre, a ver que dice:"<<endl;
cout<<"'Buenos Dias will.. tuve que entrar mas temprano al trabajo hoy, \nno se te ocurra abrir la llave del lavabo en el baño, \nen serio no la abras.'"<<endl;
cout<<"¿Ehhhh?"<<endl;
cout<<"¿que pasara con esa llave?"<<endl;
cout<<"Vale, veamos que tenemos por aqui..."<<endl;
cout<<"Abrir llave?"<<endl;
cout<<"1-si"<<endl;
cout<<"2-no"<<endl;
cin>>Decision;
if (Decision == 1){
    cout<<"Veamos..."<<endl;
    cout<<"Yo veo que esta llave funciona perfectamente"<<endl;
    cout<<"..."<<endl;
    cout<<"AHHHHHH..."<<endl;
    cout<<"bueno retiro lo dicho"<<endl;
    cout<<"¡DEMASIADA AGUA!"<<endl;
    cout<<"¿Ahora como hago para parar esto?"<<endl;
    cout<<"necesito una especie de tapon o algo parecido"<<endl;
    do{
    cout<<"*Entras a la cocina*"<<endl;
    cout<<"1-Tomar lonchera.\n2-Tomar pasta.\n3-irte. \n4-Buscar tapon. \n5-volver al baño."<<endl;
    cin>>Decision;
    if (Decision == 1 ){
        cout<<"*Tomaste la lonchera*"<<endl;
        lonchera++;
    }
    else if(Decision == 2){
        if (Pastillas == 1){
            cout<<"*Tomaste la pastilla correcta*"<<endl;
        }else{
            cout<<"Creo que esa pastilla no era"<<endl;
        }
    }
    else if (Decision == 3){
        cout<<"Aun no me puedo ir, me falta algo"<<endl;
    }
    else if (Decision == 4){
        cout<<"Ya tengo el tapon"<<endl;
        tapon = 1;
    }
    else if (Decision == 5){
        if (tapon == 1){
        cout<<"Este tapon deberia servir..."<<endl;
        cout<<"Perfecto... dejo de salir agua"<<endl;
        cout<<"¿Y ahora que hago con toda la agua?"<<endl;
        cout<<"pues...por los momentos se quedara asi, no tengo mas tiempo"<<endl;
        cout<<"debo irme a clases"<<endl;
        }else{
            cout<<"necesito una especie de tapon o algo parecido"<<endl;
        } 
    }
    } while ((Decision != 2)&&(tapon == 1));
    cout<<""<<endl;
    cout<<""<<endl;
}else{}
    do{
    cout<<"*Entras a la cocina*"<<endl;
    cout<<"1-Tomar lonchera.\n2-Tomar pasta.\n3-irte."<<endl;
    cin>>Decision;
    if (Decision == 1 ){
        cout<<"*Tomaste la lonchera*"<<endl;
        lonchera++;
    }
    else if(Decision == 2){
        if (Pastillas == 1){
            cout<<"*Tomaste la pastilla correcta*"<<endl;
        }else{
            cout<<"Creo que esa pastilla no era"<<endl;
        }
    }
    else if (Decision == 3){
        cout<<"Aun no me puedo ir, me falta algo"<<endl;
    }
    else{}
    } while ((Decision != 2));
cout<<"Ahora si me voy..."<<endl;
cout<<"*Estas en el colegio*"<<endl;
cout<<"*Nota de la directora*"<<endl;
cout<<"'Queridos Estudiantes: Se les informa la terrible noticia que el'"<<endl;
cout<<"estudiante Stuard se encuentra desaparecido, esto ocurrio la noche de ayer,"<<endl;
cout<<"si sabe o sospecha de lago por favor informar a las autoridades'"<<endl;
cout<<"...."<<endl;
cout<<"¿Stuard? que extraño."<<endl;
cout<<"quieres entrar al baño antes de clase?"<<endl;
cout<<"1-si\n2-no"<<endl;
cin>>Decision;
if (Decision == 1){
    cout<<"................"<<endl;
    cout<<"Ahh hola Tired"<<endl;
    cout<<"tired: Ya ha comenzado.. Poco a poco te dejaran de molestar."<<endl;
    cout<<"¿De que hablas?"<<endl;
    cout<<"tired: Recuerda que hacemos todo por ti will... por que te amamos"<<endl;
    cout<<"¿?¿?¿?¿?.. Ok, no entiendo nada"<<endl;
    cout<<"tired: Te estamos observando will... Observando..."<<endl;
    cout<<"*Desaparece tired y se mueve todo el mundo*"<<endl;
    cout<<"????????"<<endl;
    cout<<"¿Que fue todo eso?"<<endl;
    cout<<""<<endl;
}else if (Decision == 2){
    cout<<""<<endl;  
}
cout<<"*Entras a clase*"<<endl;
cout<<"Maestra: Buenos dias will..."<<endl;
cout<<"Buenos dias profesora"<<endl;
cout<<"Maestra: Pase adelante..."<<endl;
cout<<"......"<<endl;
cout<<"Sigamos con la clase...."<<endl;
cout<<"Recuerden que tiene examen..."<<endl;
cout<<"De matematicas...."<<endl;
cout<<"................."<<endl;
cout<<"Bueno... pueden salir a desayudar."<<endl;
cout<<"bueno, vamos a comer"<<endl;
cout<<"......................."<<endl;
if (lonchera == 2){
    cout<<"Que bueno que traje mi lochera :)"<<endl;
}else{
    cout<<"*No tragiste la lonchera*"<<endl;
    cout<<"Que hambre tengo!!"<<endl;
    mal++;
}
cout<<"Otro dia mas de colegio..."<<endl;
cout<<"Hoy tengo consulta con mi psiquiatra"<<endl;
cout<<"..........."<<endl;
cout<<"*Estas en el hospital*"<<endl;
cout<<"Mama: ¿Por que siempre tardas tanto will?"<<endl;
cout<<"...."<<endl;
cout<<"Doctor: Buenas noches"<<endl;
cout<<"Mama: Buenas noches doctor"<<endl;
cout<<"Doctor: Supe la noticia del niño desaparecido en tu colgio will, la verdad que estoy impactado"<<endl;
cout<<"Pues si, es bastante fea la noticia"<<endl;
cout<<"Mama: Es una pena"<<endl;
cout<<"Doctor: Bueno will... por favor dile que no me haga daño"<<endl;
cout<<"¿De que habla doctor?"<<endl;
cout<<"Doctor: ¡DILE QUE SE DETENGA WILL! POR FAVOR"<<endl;
cout<<"¿QUE LE PASA DOCTOR?"<<endl;
cout<<"Doctor: DILE.. DILE.. DILE.."<<endl;
cout<<"*Vez imagenes en tu cabeza del doctor muriendo*"<<endl;
cout<<"Mama: Will"<<endl;
cout<<"¿Ehhh?"<<endl;
cout<<"Mama: Respondele al doctor"<<endl;
cout<<"Doctor: ¿Te has tomado los medicamentos?"<<endl;
cout<<"Si tomo las pastillas, pero no sirven de nada."<<endl;
cout<<"Mama: Will no aceptare mas tus malas conductas con el doctor"<<endl;
cout<<"....."<<endl;
cout<<"Doctor: ¿No sirven para nada?"<<endl;
cout<<"Doctor: Will necesito que pongas de tu parte para tu recuperacion.."<<endl;
cout<<"Doctor: ¿Sigues escuchando esas voces?"<<endl;
cout<<"Si, son mis amigos imaginarios"<<endl;
cout<<"Doctor: Con que siguen los amigos imganinarios"<<endl;
cout<<"Mmmm.. si"<<endl;
cout<<"Doctor: sientes aprecio por estos amigos por lo que veo.."<<endl;
cout<<"Son amigos... Es obvio que les tengo aprecio"<<endl;
cout<<"Doctor: ¿Que tipo de cosas te dicen esas voces?"<<endl;
cout<<"Disculpe pero prefiero no hablar de eso"<<endl;
cout<<"Doctor: Es dificil poder ayudarte asi Will, necesito que me cuentes"<<endl;
cout<<"Ehhh.."<<endl;
cout<<"No es nada relevante doctor, conversaciones convencionales"<<endl;
cout<<"Mama: Seguro will?"<<endl;
cout<<"Doctor: Necesito que no me ocultes nada, por favor."<<endl;
cout<<"Estoy seguro, no digo mentiras... son solo practicas comunes y corrientes"<<endl;
cout<<"Doctor: Eso espero... Bueno will, eso es todo por hoy"<<endl;
cout<<"Doctor: Estusiare mucho mas a fondo tu caso..."<<endl;
cout<<"Doctor: nos vemos en la proxima consulta, que pasen feliz noche."<<endl;
cout<<"Adios..."<<endl;
cout<<"Mama: Que pase buena noche doctor."<<endl;
cout<<"Doctor: Vamos will pon un poco de tu parte..."<<endl;
cout<<"............"<<endl;
cout<<"*Regresas a tu casa*"<<endl;
if (tapon == 1){
    cout<<"Mama: ¿PERO QUE ES TODA ESTA AGUA?"<<endl;
    cout<<"Mama: TE DIJE QUE NO ABRIERAS LA LLAVE WILL"<<endl;  
    cout<<"Lo siento... solo queria arreglarla"<<endl;
    cout<<"Mama: Ahh...¿Ahora como saco toda esa agua?"<<endl;
    cout<<"No fue mi intencion.. lo siento"<<endl;
    cout<<"Mama: Ahhhhhh"<<endl;
    cout<<"Mama: Bueno cariño... ve a dormir, mañana resolvemos esto"<<endl;    
}else{
    cout<<"Mama: Bueno cariño... ve a dormir"<<endl;
}
cout<<"*Vas a tu cuarto*"<<endl;
cout<<"tired: ven... will... ¿estas contento?"<<endl;
cout<<"¿Por que lo estaria?"<<endl;
cout<<"tired: Ya quedan cada vez menos"<<endl;
cout<<"¿Menos que? ¿de que hablas?"<<endl;
cout<<"tired: muy pronto lo entenderas todo... muy pronto..."<<endl;
cout<<"tired: recuerda que te amamos will..."<<endl;
cout<<".............."<<endl;
cout<<"Ya amanecio.."<<endl;
do{
cout<<"Vale el medicamento"<<endl;
cout<<"1-Antipsicotico"<<endl;
cin>>Pastillas;
if (Pastillas == 1){
    cout<<"Vale ya la tengo.."<<endl;
}else{}
} while (Pastillas != 1);
cout<<"ire al refrigerador a por un poco de agua."<<endl;
cout<<"Mama: Buenos dias will"<<endl;
cout<<"Hola mama"<<endl;
cout<<"Mama: No fui a trabajar hoy... me quedare limpiando la casa"<<endl;
cout<<"Bueno..."<<endl;
cout<<"Mama: Deberias irte ya mismo... se te hacer tarde"<<endl;
cout<<"Mama: Hoy te toca comer en el comedor, no hice desayuno."<<endl;
cout<<"Esta bien mama."<<endl;
do{
    cout<<"1-Tomar pasta.\n2-irte."<<endl;
    cin>>Decision;
    if (Decision == 1 ){
            cout<<"*Tomaste la pastilla correcta*"<<endl;
    }
    else if (Decision == 2){
        cout<<"Aun no me puedo ir, me falta algo"<<endl;
    }
    else{}
    } while ((Decision != 1));
cout<<"Me voy..."<<endl;
cout<<"*Estas en el colegio*"<<endl;
cout<<"*Nota de la directora*"<<endl;
cout<<"'Desafortunadas noticias para la escuela..."<<endl;
cout<<"Aumentan los casos de desaparicion en 2"<<endl;
cout<<"No solo el joven Stuard, si no, carbon es el joven recien desaparecido"<<endl;
cout<<"Necesitamos el apoyo de todos para poder llegar al caso.'"<<endl;
cout<<"No puede ser..."<<endl;
cout<<"¿Por que esta pasando esto?"<<endl;
cout<<"*Entras a clase*"<<endl;
cout<<"Maestra: Buenos dias will..."<<endl;
cout<<"Buenos dias profesora"<<endl;
cout<<"Maestra: Se que es muy triste lo que esta pasando......"<<endl;
cout<<"Maestra: pero los encontraremos...."<<endl;
cout<<"Maestra: pronto...."<<endl;
cout<<"....................."<<endl;
cout<<"Maestra: Bueno, pueden salir a desayunar"<<endl;
cout<<"*Vas hacia el comedor, pero...*"<<endl;
cout<<"Wow... primera vez que veo esta puerta abierta"<<endl;
cout<<"¿Que habra ahi dentro?"<<endl;
cout<<"HEY... HEY..."<<endl;
cout<<"Alguien cerro la puerta"<<endl;
cout<<"chuck: JA JA JA JA JA..."<<endl;
cout<<"¿chuck?"<<endl;
cout<<"chuck: Exacto will..."<<endl;
cout<<"vamos amigo dejame salir, por favor"<<endl;
cout<<"chuck: jajajajaj.. no gusano, tu te quedas ahi encerrado"<<endl;
cout<<"chuck: la puerta esta cerrada con llave, asi que adiosito"<<endl;
cout<<"Hey... por favor no te vayas, hare lo que sea"<<endl;
cout<<"HEY... ¿Alguien?"<<endl;
cout<<"¡POR FAVOR AYUDA!"<<endl;
cout<<".............."<<endl;
cout<<"¿Y ahora que hago?"<<endl;
cout<<"tired: Hey will...."<<endl;
cout<<"¿tired?"<<endl;
cout<<"tired: JE JE JE JE... ¿Como lo supiste?"<<endl;
cout<<"Ehhh... no sera porque escucho tu voz"<<endl;
cout<<"tired: ahhhh, si cierto, soy tonto jejeje...."<<endl;
cout<<"Hey tired, podrias darme una mano para poder salir de aqui"<<endl;
cout<<"tired: no dudes con eso mi pequeño will..... ja ja ja ja"<<endl;
cout<<"tired: pronto sabra quien es el que manda aqui"<<endl;
cout<<"Ehhhhh... vale, ¿pero de que forma me vas a ayudar?"<<endl;
cout<<"tired: tu tranquilo will, ten un poco de paciencia..."<<endl;
cout<<"......."<<endl;
do{
cout<<"Mas adelante hay una puerta, entrar?"<<endl;
cout<<"1-si"<<endl;
cout<<"2-no"<<endl;
cin>>Decision;
} while ((Decision != 1));
cout<<"Hay unos libros con un orden especifico"<<endl;
cout<<"1-La llamada de Cthulhu"<<endl;
cout<<"2-En las montañas de la locura"<<endl;
cout<<"3-Los gatos de Ultha"<<endl;
do{
cout<<"Hay varias puertas con diferente nombres, por cual entrar?"<<endl;
cout<<"1-El horror de Dunwich"<<endl;
cout<<"2-La llamada de Cthulhu"<<endl;
cout<<"3-Las ratas de las paredes"<<endl;
cout<<"4-En la noche de los tiempos"<<endl;
cin>>Decision;
if (Decision == 2){
    cout<<"Hay varias puertas con diferente nombres, por cual entrar?"<<endl;
    cout<<"1-La sombra sobre Innsmouth"<<endl;
    cout<<"2-Dagon"<<endl;
    cout<<"3-El Necronomicon"<<endl;
    cout<<"4-En las montañas de la locura"<<endl;
    cin>>Decision;
    if (Decision == 4){
        cout<<"Hay varias puertas con diferente nombres, por cual entrar?"<<endl;
        cout<<"1-El que susurra en la oscuridad"<<endl;
        cout<<"2-El morador de las tinieblas"<<endl;
        cout<<"3-Los gatos de Ultha"<<endl;
        cout<<"4-El"<<endl;
        cin>>Decision;
        if (Decision == 3){
            cout<<"Vale.. segun los tres libros esta es la ultima"<<endl;
            cout<<"Eso lo veremos..."<<endl;
            Decision = 22;
        }else{}
    }else{}
}else{}
} while ((Decision != 22));
cout<<"Pues al parecer si,"<<endl;
do{
cout<<"Ya no veo las mismas puertas molestas...."<<endl;
cout<<"..."<<endl;
cout<<"Aqui hay un hueco en la pared."<<endl;
cout<<"pero no es lo suficiente grande como para que yo pase..."<<endl;
cout<<"..."<<endl;
cout<<"Creo que con un buen golpe lograre abrirlo mas..."<<endl;
cout<<"... pero mis puños no son tan fuertes como para romper una pared."<<endl;
do{
cout<<"hay una puerta entrar?"<<endl;
cout<<"1-si"<<endl;
cout<<"2-no"<<endl;
cin>>Decision;
} while ((Decision != 1));
cout<<".............¿En serio?"<<endl;
cout<<"aqui abajo escribieron 'Gusano'"<<endl;
cout<<"pero espera..."<<endl;
cout<<"¿esto esta hecho con sangre?"<<endl;
cout<<"!!!!!!!!!!!!!!!!"<<endl;
cout<<"Dios... ¿que ha sido eso?"<<endl;
cout<<"........"<<endl;
cout<<"que.. que.. QUE ES ESO..."<<endl;
cout<<"*Te persigue un monstruo de 3 metros*"<<endl;
cout<<"1-Correr"<<endl;
cout<<"2-Dejar que te atrape"<<endl;
cin>>Decision;
} while ((Decision != 1));
cout<<"???????????????"<<endl;
cout<<"¿¡Que demonios ha sido eso!?"<<endl;
cout<<"Ahhhhhh mi cabeza..."<<endl;
cout<<"necesito salir de aqui"<<endl;
do{
cout<<"hay varios objetos, los necesitare?"<<endl;
cout<<"1-Martillo"<<endl;
cout<<"2-Pico"<<endl;
cout<<"3-Destornillador"<<endl;
cin>>Decision;
if (Decision == 1){
    cout<<"*Tienes un Martillo*"<<endl;
    martillo = 1;
}else if (Decision == 2){
    cout<<"*Tienes un Pico*"<<endl;
    pico = 1;
}else if (Decision == 3){
    cout<<"*Tienes un Destornillador*"<<endl;
    destornillador = 1;
}
do{
cout<<"Hay un puerta adelante,entrar?"<<endl;
cout<<"1-si"<<endl;
cout<<"2-no"<<endl;
cin>>Decision;
} while ((Decision != 1));
if (conver == 0){
    cout<<"¿?¿?¿?¿?¿?"<<endl;
    cout<<"Reflection: ¿Dime que le vamos a decir?"<<endl;
    cout<<"Help: Creo que esta vez si se volvio loco"<<endl;
    cout<<"¿Hola?"<<endl;
    cout<<"Reflection: ¡AHHHHHH! Will... Que susto por Dios"<<endl;
    cout<<"¿Que hacen aqui?"<<endl;
    cout<<"Help: Acompañandote..."<<endl;
    cout<<"¿Acompañandome? pero si estoy encerrado y perdido en este lugar..."<<endl;
    cout<<"¿No pueden ayudar?"<<endl;
    cout<<"Help: Me temo que no will... Tired nos lo prohibio"<<endl;
    cout<<"¿Que..? ¿por que?"<<endl;
    cout<<"Help: Will, el esta algo cambiado, es mejor no hacerlo enojar"<<endl;
    cout<<"¿Pero...?"<<endl;
    conver = 1;
}
do{
cout<<"Reflection: Lo sentimos"<<endl;
cout<<"1-Devolverse"<<endl;
cin>>Decision;
} while ((Decision != 1));
do{
cout<<"Romper pared con"<<endl;
cout<<"1-Martillo"<<endl;
cout<<"2-Pico"<<endl;
cout<<"3-Destornillador"<<endl;
cout<<"4-Devolverse"<<endl;
cin>>Decision;
if (Decision == 1){
    if (martillo == 1){
        cout<<"Se rompio la pared"<<endl;
    }else{
        cout<<"No tienes Martillo"<<endl;
    }
}else if (Decision == 2){
    if (pico == 1){
        cout<<"El pico no es tan fuerte"<<endl;
    }else{
        cout<<"No tienes pico"<<endl;
    }
}else if (Decision == 3){
    if (destornillador == 1){
        cout<<"El Destornillador no es tan fuerte"<<endl;
    }else{
        cout<<"No tienes Destornillador"<<endl;
    }
}else if (Decision == 4){
    Decision = 23;
}
} while (Decision != 23);
} while (martillo != 1);
cout<<"Vamos a mirar que hay del otro lado"<<endl;
cout<<"Ahhhhh..."<<endl;
cout<<"Estas rocas cerraron el paso."<<endl;
cout<<"no hay vuleta atras"<<endl;
cout<<"hay una puerta, pero esta cerrada"<<endl;
cout<<"Necesita una llave..."<<endl;
cout<<"Hay una nota:"<<endl;
cout<<"'Si llegaste hasta aqui, buen trabajo me descubriste, esto no es lo que parece... ¿o si?"<<endl;
cout<<"que quede claro que no estoy loco'"<<endl;
cout<<"¿?¿?¿?¿?¿?¿?"<<endl;
cout<<"Que miedo...¿Quien habra escrito eso?"<<endl;
cout<<"¿tendra que ver con los niños desaparecidos?"<<endl;
cout<<"la verdad no tengo idea, pero debe salir de aqui"<<endl;
cout<<"!!!!!!!!!!!!!"<<endl;
cout<<"Por Dios...¿Que es esto?"<<endl;
cout<<"*Encuentras tres bolsas colgadas*"<<endl;
cout<<"¿Que es esto? tiene un muy mal olor,"<<endl;
cout<<"esta algo suave, y siento pequeñas cosas que se mueven en su interior"<<endl;
cout<<"nada que pueda hacer con esto"<<endl;
cout<<"................"<<endl;
cout<<"Espera un momento,"<<endl;
cout<<"Al tocar esta siento algo diferente en su interior, intentare sacarlo"<<endl;
cout<<"..........."<<endl;
cout<<"Vale es una llave"<<endl;
cout<<"*Entrar por la puerta con la llave*"<<endl;
cout<<"No me siento muy bien"<<endl;
cout<<"No... no... he..."<<endl;
cout<<"comido nada..."<<endl;
cout<<"¿esos niños desaparecidos que tienen que ver conmigo?,"<<endl;
cout<<"creo que me voy a desmayar"<<endl;
cout<<".................."<<endl;
cout<<"*Aparece tired con las bolsas colgadas y poco a poco se tranforma en nosotros*"<<endl;
cout<<".................."<<endl;
cout<<"Mama: will, no sabia que te molestaban en el colegio"<<endl;
cout<<"Siempre lo han hecho."<<endl;
cout<<"Mama: ¿como es posible que te hayan dejado encerrado ahi solo?"<<endl;
cout<<"Mama: sin comida, sin nada"<<endl;
cout<<"Mama: ¿Que clase de educacion reciben esos niños?"<<endl;
cout<<"Mama: si no fuese por el conserje, estarias aun alla abajo..."<<endl;
cout<<"Mama: hablare con la directora para que pongan orden"<<endl;
cout<<"Noooooo, si no ellos la pagaran conmigo, aun peor."<<endl;
cout<<"Mama: Veremos que hacemos, pero eso no puede seguir asi"<<endl;
cout<<".........."<<endl;
cout<<"Mama: Bueno, que pases buena noche Will"<<endl;
cout<<"Mama, no sabes lo mucho que extraño a Papa"<<endl;
cout<<"Cada dia lo recuerdo mas y cada dia mas me duele"<<endl;
cout<<"Mama: Se fuerte will, el ya no esta entre nosotros..."<<endl;
cout<<"Mama: Se fuerte."<<endl;
cout<<"Cuanto te extraño..."<<endl;
cout<<"....."<<endl;
cout<<"¿Que me esta pasando?"<<endl;
cout<<"..........."<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
cout<<""<<endl;
}